<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="com.tracker.model.Category" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add Expense - Expense Tracker</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <% 
        if (session.getAttribute("userId") == null) {
            response.sendRedirect("login");
        }
    %>
    
    <div class="navbar">
        <div class="navbar-brand">Expense Tracker</div>
        <div class="navbar-menu">
            <a href="dashboard" class="nav-link">Dashboard</a>
            <a href="expense?action=view" class="nav-link">Expenses</a>
            <a href="expense?action=add" class="nav-link active">Add Expense</a>
            <a href="logout" class="nav-link">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="form-container">
            <h1>Add New Expense</h1>
            
            <% 
                String error = (String) request.getAttribute("error");
                if (error != null) {
            %>
                <div class="alert alert-error"><%= error %></div>
            <% } %>
            
            <form action="expense" method="POST" class="form">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label for="categoryId">Category:</label>
                    <select id="categoryId" name="categoryId" required>
                        <option value="">-- Select Category --</option>
                        <%
                            List<Category> categories = (List<Category>) request.getAttribute("categories");
                            if (categories != null) {
                                for (Category category : categories) {
                        %>
                                    <option value="<%= category.getCategoryId() %>"><%= category.getCategoryName() %></option>
                        <%
                                }
                            }
                        %>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="amount">Amount:</label>
                    <input type="number" id="amount" name="amount" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" rows="4"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="expenseDate">Date:</label>
                    <input type="date" id="expenseDate" name="expenseDate" required>
                </div>
                
                <button type="submit" class="btn btn-primary">Add Expense</button>
                <a href="expense?action=view" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>
