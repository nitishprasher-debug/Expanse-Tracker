<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="com.tracker.model.Category" %>
<%@ page import="com.tracker.model.Expense" %>
<%@ page import="java.text.SimpleDateFormat" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Expense - Expense Tracker</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <% 
        if (session.getAttribute("userId") == null) {
            response.sendRedirect("login");
        }
    %>
    
    <div class="navbar">
        <div class="navbar-brand">Expense Tracker</div>
        <div class="navbar-menu">
            <a href="dashboard" class="nav-link">Dashboard</a>
            <a href="expense?action=view" class="nav-link">Expenses</a>
            <a href="expense?action=add" class="nav-link">Add Expense</a>
            <a href="logout" class="nav-link">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="form-container">
            <h1>Edit Expense</h1>
            
            <% 
                String error = (String) request.getAttribute("error");
                if (error != null) {
            %>
                <div class="alert alert-error"><%= error %></div>
            <% } %>
            
            <%
                Expense expense = (Expense) request.getAttribute("expense");
                if (expense != null) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String dateStr = sdf.format(expense.getExpenseDate());
            %>
                <form action="expense" method="POST" class="form">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="expenseId" value="<%= expense.getExpenseId() %>">
                    
                    <div class="form-group">
                        <label for="categoryId">Category:</label>
                        <select id="categoryId" name="categoryId" required>
                            <option value="">-- Select Category --</option>
                            <%
                                List<Category> categories = (List<Category>) request.getAttribute("categories");
                                if (categories != null) {
                                    for (Category category : categories) {
                            %>
                                        <option value="<%= category.getCategoryId() %>" 
                                            <%= category.getCategoryId() == expense.getCategoryId() ? "selected" : "" %>>
                                            <%= category.getCategoryName() %>
                                        </option>
                            <%
                                    }
                                }
                            %>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="amount">Amount:</label>
                        <input type="number" id="amount" name="amount" step="0.01" min="0" 
                               value="<%= expense.getAmount() %>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description:</label>
                        <textarea id="description" name="description" rows="4"><%= expense.getDescription() %></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="expenseDate">Date:</label>
                        <input type="date" id="expenseDate" name="expenseDate" 
                               value="<%= dateStr %>" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Update Expense</button>
                    <a href="expense?action=view" class="btn btn-secondary">Cancel</a>
                </form>
            <%
                } else {
            %>
                <p>Expense not found. <a href="expense?action=view">Back to expenses</a></p>
            <%
                }
            %>
        </div>
    </div>
</body>
</html>
