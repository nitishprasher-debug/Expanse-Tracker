# Expense Tracker Web Application

A Java-based web application for tracking and managing personal expenses using Servlet, JSP, and JDBC with a MySQL database.

## Project Overview

**Course:** Advanced Internet Programming (AIP)
**Units Covered:** Unit-1 (Servlets), Unit-2 (JSP & JDBC)

### Key Features

- **User Authentication:** Register, login, and logout functionality
- **Expense Management:** Add, view, edit, and delete expenses
- **Category Management:** Organize expenses by categories
- **Dashboard:** View expense summary and recent transactions
- **Secure Sessions:** HTTP session-based user authentication
- **Responsive UI:** Mobile-friendly interface

## Technology Stack

- **Backend:** Jakarta Servlets (Servlet 6.0)
- **Frontend:** JSP (Java Server Pages), HTML5, CSS3
- **Database:** MySQL
- **JDBC:** Java Database Connectivity for database operations
- **Server:** Apache Tomcat 10.1+
- **Java Version:** Java 11 or higher

## Project Structure

```
ExpenseTracker/
├── src/
│   └── com/tracker/
│       ├── servlet/
│       │   ├── LoginServlet.java
│       │   ├── RegisterServlet.java
│       │   ├── LogoutServlet.java
│       │   ├── DashboardServlet.java
│       │   └── ExpenseServlet.java
│       ├── model/
│       │   ├── User.java
│       │   ├── Expense.java
│       │   └── Category.java
│       ├── dao/
│       │   ├── UserDAO.java
│       │   ├── ExpenseDAO.java
│       │   └── CategoryDAO.java
│       └── util/
│           └── DatabaseConnection.java
├── WebContent/
│   ├── index.jsp
│   ├── login.jsp
│   ├── register.jsp
│   ├── dashboard.jsp
│   ├── addExpense.jsp
│   ├── viewExpenses.jsp
│   ├── editExpense.jsp
│   ├── css/
│   │   └── style.css
│   └── WEB-INF/
│       └── web.xml
├── database/
│   └── schema.sql
└── README.md
```

## Prerequisites

1. **Java Development Kit (JDK):** Version 11 or higher
2. **Apache Tomcat:** Version 10.1 or higher
3. **MySQL Server:** Version 5.7 or higher
4. **MySQL JDBC Driver:** mysql-connector-java (place the JAR in `WebContent/WEB-INF/lib/`)
5. **IDE:** Eclipse, IntelliJ IDEA, or VS Code with Java extensions

## Installation & Setup

### Step 1: Create Database

1. Open MySQL Command Line or MySQL Workbench
2. Run the following commands:

```sql
-- Execute the schema.sql file or run these commands directly
SOURCE path/to/ExpenseTracker/database/schema.sql;
```

Alternatively, copy and paste the contents of `database/schema.sql` into your MySQL client.

### Step 2: Update Database Connection

Edit `src/com/tracker/util/DatabaseConnection.java`:

```java
private static final String URL = "jdbc:mysql://localhost:3306/expense_tracker";
private static final String USER = "root";
private static final String PASSWORD = "root";
```

Override these values with system properties or environment variables if your local MySQL setup differs:

- `expense.db.url` or `EXPENSE_DB_URL`
- `expense.db.user` or `EXPENSE_DB_USER`
- `expense.db.password` or `EXPENSE_DB_PASSWORD`

### Step 3: Add MySQL JDBC Driver

1. Download MySQL Connector/J from: https://dev.mysql.com/downloads/connector/j/
2. Add the JAR file to: `WebContent/WEB-INF/lib/`

### Step 4: Deploy to Tomcat

**Option 1: Using IDE (Eclipse/IntelliJ)**
1. Create a new Dynamic Web Project
2. Copy project files to the project directory
3. Right-click on project → Run on Server → Select Tomcat
4. Application will be deployed at: `http://localhost:8080/ExpenseTracker`

**Option 2: Manual Deployment**
1. Build the project to create a WAR file
2. Copy the WAR file to: `TOMCAT_HOME/webapps/`
3. Restart Tomcat server
4. Access the application at: `http://localhost:8080/ExpenseTracker`

### Deployment Note

This project uses `jakarta.servlet.*` imports and a Servlet 6.0 deployment descriptor, so it should be run on Tomcat 10.1 or later. If you need to stay on Tomcat 9, switch the imports and `web.xml` back to `javax.servlet.*` and Servlet 4.0.

## Usage Guide

### User Workflow

1. **Home Page:**
   - Navigate to `http://localhost:8080/ExpenseTracker/`
   - Choose to Login or Register

2. **Registration:**
   - Click "Register here" link
   - Fill in username, email, password
   - Click "Register" button
   - You will be redirected to login page

3. **Login:**
   - Enter your username and password
   - Click "Login" button
   - You will be redirected to dashboard

4. **Dashboard:**
   - View total expenses and expense count
   - See recent 5 expenses
   - Navigate using top menu bar

5. **Add Expense:**
   - Click "Add Expense" from navigation
   - Select category
   - Enter amount, description, and date
   - Click "Add Expense"

6. **View Expenses:**
   - Click "Expenses" in navigation
   - See all your expenses with total sum
   - Edit or delete expenses as needed

7. **Edit Expense:**
   - Click "Edit" button on expense row
   - Modify the details
   - Click "Update Expense"

8. **Delete Expense:**
   - Click "Delete" button on expense row
   - Confirm deletion in popup

9. **Logout:**
   - Click "Logout" in navigation menu
   - Session will be destroyed
   - Redirected to login page

## Servlet Mappings

| Servlet | URL Pattern | Methods | Description |
|---------|-------------|---------|-------------|
| LoginServlet | /login | GET, POST | User login functionality |
| RegisterServlet | /register | GET, POST | User registration |
| LogoutServlet | /logout | GET | User logout |
| DashboardServlet | /dashboard | GET | Dashboard view (requires session) |
| ExpenseServlet | /expense | GET, POST | Expense CRUD operations |

## JSP Pages

- **index.jsp:** Welcome/home page
- **login.jsp:** User login form
- **register.jsp:** User registration form
- **dashboard.jsp:** Main dashboard with overview
- **addExpense.jsp:** Form to add new expense
- **viewExpenses.jsp:** List all expenses with CRUD actions
- **editExpense.jsp:** Edit existing expense

## Database Schema

### Tables

**users**
- user_id (INT, Primary Key, Auto Increment)
- username (VARCHAR(50), Unique)
- password (VARCHAR(100))
- email (VARCHAR(100))
- created_date (TIMESTAMP)

**categories**
- category_id (INT, Primary Key, Auto Increment)
- user_id (INT, Foreign Key)
- category_name (VARCHAR(50))
- description (VARCHAR(255))
- created_date (TIMESTAMP)

**expenses**
- expense_id (INT, Primary Key, Auto Increment)
- user_id (INT, Foreign Key)
- category_id (INT, Foreign Key)
- amount (DECIMAL(10,2))
- description (VARCHAR(255))
- expense_date (DATE)
- created_date (TIMESTAMP)
- updated_date (TIMESTAMP)

## JDBC Operations (CRUD)

### Create
- Add new user (RegisterServlet)
- Add new expense (ExpenseServlet)
- Add new category (CategoryDAO)

### Read
- Get user by ID (UserDAO)
- Get all expenses (ExpenseDAO)
- Get categories (CategoryDAO)
- Login user authentication (UserDAO)

### Update
- Update expense (ExpenseDAO)
- Update user info (UserDAO)

### Delete
- Delete expense (ExpenseDAO)

## Key Concepts Implemented

### Unit-1: Servlet & Client-Server Architecture
- **Servlet Architecture:** Request/Response flow
- **HttpServletRequest & HttpServletResponse:** Parameter handling and responses
- **GET and POST Methods:** Data submission via forms
- **Servlet Lifecycle:** init(), service(), destroy()
- **Session Management:** User authentication using HttpSession
- **Request Dispatcher:** Forward requests between servlets

### Unit-2: JSP & JDBC
- **JSP Elements:** Scripting elements, directives, expressions
- **Implicit Objects:** request, response, session, out
- **JDBC Operations:** Connection, Statement, PreparedStatement, ResultSet
- **CRUD Operations:** Insert, Update, Delete, Select queries
- **Prepared Statements:** For safe SQL queries (SQL injection prevention)
- **Connection Management:** JDBC database connectivity

## Security Features

1. **Session Management:** User must login to access protected pages
2. **Input Validation:** Form data validation on both client and server
3. **Prepared Statements:** Protection against SQL injection attacks
4. **Password Handling:** (Note: In production, implement password hashing)

## Troubleshooting

### Issue: Database Connection Failed
**Solution:**
- Verify MySQL server is running
- Check database credentials in DatabaseConnection.java
- Ensure mysql-connector-java JAR is in WEB-INF/lib/

### Issue: 404 Error on Servlet Pages
**Solution:**
- Verify servlet mappings in web.xml
- Check servlet class names and package names
- Ensure application is properly deployed

### Issue: Session Lost After Logout
**Solution:**
- This is expected behavior - session is invalidated on logout
- User must login again to create new session

### Issue: JSP Pages Not Rendering
**Solution:**
- Verify JSP files are in WebContent directory
- Check that Tomcat is configured as application server
- Clear browser cache and reload

## Testing

### Manual Testing Steps

1. **Test Registration:**
   - Register with new username, email, password
   - Try duplicate username (should fail)
   - Try mismatched passwords (should fail)

2. **Test Login:**
   - Login with valid credentials
   - Try invalid password (should fail)
   - Verify session is created

3. **Test Expense Management:**
   - Add multiple expenses with different categories
   - Verify total calculation
   - Edit expense details
   - Delete expense and verify removal

4. **Test Session Security:**
   - Logout and try accessing dashboard directly
   - Should redirect to login page

## Future Enhancements

1. **Password Hashing:** Implement bcrypt for secure password storage
2. **Email Verification:** Send verification emails during registration
3. **Expense Reports:** Generate monthly/yearly expense reports
4. **Budget Planning:** Set monthly budgets and alerts
5. **Data Export:** Export expenses to CSV/PDF formats
6. **Mobile App:** Develop Android/iOS native applications
7. **REST APIs:** Create REST endpoints for web services
8. **Authentication:** Implement OAuth 2.0 for third-party login
9. **Analytics:** Add charts and graphs for expense visualization
10. **Notifications:** Email alerts for high spending months

## Deployment to Production

### Recommended Steps

1. **Security:**
   - Enable HTTPS/SSL
   - Use environment variables for sensitive data
   - Implement password hashing (bcrypt)
   - Add CSRF protection tokens

2. **Database:**
   - Use dedicated database user with limited privileges
   - Enable database backups
   - Implement database connection pooling

3. **Server:**
   - Run Tomcat as non-root user
   - Keep Java and Tomcat updated
   - Configure proper logging
   - Set up monitoring and alerts

4. **Code:**
   - Implement comprehensive error handling
   - Add logging for debugging
   - Optimize database queries
   - Implement caching mechanisms

## References

- **Servlet API Documentation:** https://tomcat.apache.org/
- **JSP Documentation:** https://projects.eclipse.org/projects/ee4j.jsp
- **JDBC Tutorial:** https://docs.oracle.com/javase/tutorial/jdbc/
- **MySQL Documentation:** https://dev.mysql.com/doc/
- **Best Practices:** https://owasp.org/

## License

This project is created for educational purposes as part of the Advanced Internet Programming course.

## Author

Created as a learning project for servlet and JSP development with JDBC database connectivity.

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review the console logs in Tomcat
3. Check MySQL error logs
4. Verify all configuration settings

---

**Happy Expense Tracking!**
