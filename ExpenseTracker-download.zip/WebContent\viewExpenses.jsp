<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="com.tracker.model.Expense" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>View Expenses - Expense Tracker</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <% 
        if (session.getAttribute("userId") == null) {
            response.sendRedirect("login");
        }
    %>
    
    <div class="navbar">
        <div class="navbar-brand">Expense Tracker</div>
        <div class="navbar-menu">
            <a href="dashboard" class="nav-link">Dashboard</a>
            <a href="expense?action=view" class="nav-link active">Expenses</a>
            <a href="expense?action=add" class="nav-link">Add Expense</a>
            <a href="logout" class="nav-link">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="expenses-section">
            <h1>My Expenses</h1>
            
            <% 
                String success = request.getParameter("success");
                String error = request.getParameter("error");
                if (success != null) {
            %>
                <div class="alert alert-success"><%= success %></div>
            <% } %>
            <% 
                if (error != null) {
            %>
                <div class="alert alert-error"><%= error %></div>
            <% } %>
            
            <div class="button-group">
                <a href="expense?action=add" class="btn btn-primary">Add New Expense</a>
            </div>
            
            <%
                List<Expense> expenses = (List<Expense>) request.getAttribute("expenses");
                if (expenses != null && !expenses.isEmpty()) {
            %>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Amount</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <%
                            double totalAmount = 0;
                            for (Expense expense : expenses) {
                                totalAmount += expense.getAmount();
                        %>
                            <tr>
                                <td><%= expense.getExpenseDate() %></td>
                                <td><%= expense.getCategoryName() %></td>
                                <td><%= expense.getDescription() %></td>
                                <td>$<%= String.format("%.2f", expense.getAmount()) %></td>
                                <td>
                                    <a href="expense?action=edit&expenseId=<%= expense.getExpenseId() %>" class="btn-small">Edit</a>
                                    <a href="expense?action=delete&expenseId=<%= expense.getExpenseId() %>" class="btn-small" onclick="return confirm('Are you sure you want to delete this expense?');">Delete</a>
                                </td>
                            </tr>
                        <%
                            }
                        %>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="3">Total</th>
                            <th>$<%= String.format("%.2f", totalAmount) %></th>
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            <%
                } else {
            %>
                <p>No expenses found. <a href="expense?action=add">Add your first expense</a></p>
            <%
                }
            %>
        </div>
    </div>
</body>
</html>
