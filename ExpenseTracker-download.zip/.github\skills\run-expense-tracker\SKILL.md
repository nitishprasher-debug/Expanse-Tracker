---
name: run-expense-tracker
description: 'Run and verify the ExpenseTracker Java Servlet/JSP app on Tomcat with MySQL. Use when asked how to run this project, set it up locally, fix startup issues, or validate that deploy/login/database flow works.'
argument-hint: 'Optional: quick|full, eclipse, db-password=<value>, tomcat-path=<path>'
user-invocable: true
---

# Run ExpenseTracker

## Outcome
Get the ExpenseTracker web app running at `http://localhost:8080/ExpenseTracker/` with a working database connection and verified login/dashboard flow.

## When To Use
- User asks: "how to run this", "start this project", "setup and run ExpenseTracker"
- Need repeatable local setup for Java + Tomcat + MySQL
- Need a troubleshooting path for run/deploy/database errors

## Inputs
- Preferred mode: `quick` or `full`
- Deployment path: default `eclipse` with Tomcat 10.1
- Optional database password override
- Optional Tomcat home path

## Procedure
1. Confirm prerequisites.
2. Initialize database schema.
3. Validate DB credentials in code.
4. Ensure MySQL JDBC driver is available.
5. Deploy to Tomcat (IDE or manual).
6. Verify app URL and key user flow.
7. If broken, run troubleshooting branches.

## Step 1: Confirm Prerequisites
Check:
- JDK 8+
- Apache Tomcat 10.1+
- MySQL 5.7+
- Eclipse IDE with Tomcat 10.1 configured as server runtime

If any are missing, stop and provide install links/commands before continuing.

## Step 2: Initialize Database
Run the schema in `database/schema.sql` against MySQL.
Expected DB:
- `expense_tracker`
Expected tables:
- `users`
- `categories`
- `expenses`

Completion check:
- Schema import completes without SQL errors.

## Step 3: Validate DB Credentials
Open `src/com/tracker/util/DatabaseConnection.java` and confirm:
- URL: `jdbc:mysql://localhost:3306/expense_tracker`
- USER: `root` (or user-provided)
- PASSWORD matches local MySQL password

Completion check:
- Credentials are aligned with local MySQL config.

## Step 4: JDBC Driver Availability
Ensure MySQL Connector/J jar is present in:
- `WebContent/WEB-INF/lib/`

If absent:
- Download Connector/J and place jar in the folder above.

Completion check:
- Deployable artifact contains the JDBC driver jar.

## Step 5: Deploy (Default: Eclipse + Tomcat 10.1)
1. Import the project in Eclipse as a Dynamic Web Project.
2. Add/configure Apache Tomcat 10.1 in Eclipse servers.
3. Run the project on server.
4. Open `http://localhost:8080/ExpenseTracker/`.

Optional fallback (manual):
1. Build WAR from project.
2. Copy WAR to `<TOMCAT_HOME>/webapps/`.
3. Start/restart Tomcat.
4. Open `http://localhost:8080/ExpenseTracker/`.

Completion check:
- Home page (`index.jsp`) loads with HTTP 200.

## Step 6: Smoke Test Flow
1. Register a user.
2. Login.
3. Open dashboard.
4. Add one expense.
5. Open expense list and verify data.

Completion check:
- Login/session works.
- Dashboard and expense pages render.
- Expense CRUD path works at least for create/read.

## Troubleshooting Branches
### Database Connection Failed
Check:
- MySQL service is running.
- DB name and credentials in `DatabaseConnection.java`.
- Connector/J jar in `WEB-INF/lib`.

### 404 On Routes
Check:
- App context path is `ExpenseTracker`.
- Servlet mappings in `WebContent/WEB-INF/web.xml` for `/login`, `/register`, `/dashboard`, `/expense`.
- Project deployed successfully in Tomcat manager/logs.

### Tomcat 10.1 Compatibility Errors
Symptoms:
- Compile/runtime errors related to `javax.servlet.*` classes.

Check:
- If codebase still uses `javax.servlet`, either run on Tomcat 9.x or migrate imports/dependencies to `jakarta.servlet` for Tomcat 10.1.
- Ensure Eclipse target runtime and servlet API dependency match the chosen Tomcat major version.

### JSP Not Rendering
Check:
- JSP files are under `WebContent/`.
- Deployment contains JSP files.
- Tomcat logs for compilation errors.

## Minimal Response Format
When running this skill, respond with:
1. What is already configured.
2. Exact next command/action.
3. What to verify next.
4. If blocked, smallest fix to unblock.

## Quick Mode
If mode is `quick`:
- Skip deep explanation.
- Perform only required steps to reach first successful app load.
- Report unresolved risks at the end.

Default behavior:
- Use `quick` mode unless user explicitly asks for full validation.

## Full Mode
If mode is `full`:
- Include all verification checks and one troubleshooting pass.
- Confirm register/login/dashboard/add-expense flow.
